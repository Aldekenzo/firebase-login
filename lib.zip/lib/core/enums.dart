
enum EnvironmentType {
  development,
  production
}

enum UsernameType {
  phone,
  email,
  google,
}
