const String AuthRoute = "/auth_screen";
const String ConfirmCodeRoute = "/confirm_code";
const String AddProfileLoginRoute = "/add_profile_login";
const String AddFlatLoginRoute = "/add_flat_login";
// const String InitialRoute = "/initial";
// const String HomeRoute = "/home";
// const String NewRequestRoute = "/new_request";
// const String PublishOrderCategoryRoute = "/publish_order_category";
// const String PublishOrderDescriptionRoute = "/publish_order_description";
// const String PublishOrderDateRoute = "/publish_order_date";
// const String MenuRoute = "/menu";
// const String ProfileRoute = "/profile_screen";
// const String FlatListRoute = "/flat_list";
// const String PublishFlatRoute = "/publish_flat";
// const String EditFlatRoute = "/edit_flat";
// const String OrderListRoute = "/order_list";
// const String ChatsRoute = "/chats";
// const String ChatRoute = "/chat";
// const String MeetUpRoute = "/meet_up";
// const String AccountListRoute = "/account_list";
// const String OrganizationRoute = "/organization";
// const String SettingsRoute = "/settings";
// const String FeedbackRoute = "/feedback";



