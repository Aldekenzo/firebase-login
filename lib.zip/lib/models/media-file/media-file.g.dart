// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'media-file.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MediaFile _$MediaFileFromJson(Map<String, dynamic> json) {
  return MediaFile(
    id: json['id'] as int?,
    file: json['file'] as String?,
  );
}

Map<String, dynamic> _$MediaFileToJson(MediaFile instance) => <String, dynamic>{
      'id': instance.id,
      'file': instance.file,
    };
