// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_credentials.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserCredentials _$UserCredentialsFromJson(Map<String, dynamic> json) {
  return UserCredentials(
    isCodeCorrect: json['isCodeCorrect'] as bool?,
  );
}

Map<String, dynamic> _$UserCredentialsToJson(UserCredentials instance) =>
    <String, dynamic>{
      'isCodeCorrect': instance.isCodeCorrect,
    };
